package com.drools.model;

public class ClaimsDecesionDTO {
	
	public static final boolean YES=true;
	public static final boolean NO=false;
	
	private double duration;
	private double age;
	private double sar;
	private String death_code;
	
	public String getDeath_code() {
		return death_code;
	}
	public void setDeath_code(String death_code) {
		this.death_code = death_code;
	}
	private boolean decesion;

	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}
	public double getAge() {
		return age;
	}
	public void setAge(double age) {
		this.age = age;
	}
	public double getSar() {
		return sar;
	}
	public void setSar(double sar) {
		this.sar = sar;
	}
	public boolean isDecesion() {
		return decesion;
	}
	public void setDecesion(boolean decesion) {
		this.decesion = decesion;
	}
	
	

}
